package pages;

import org.openqa.selenium.WebDriver;

public class AccountPage extends PageBase {

    public AccountPage(WebDriver driver) {
        super(driver);
    }
}